import React from "react";

export function About() {
  return (
    <section className="py-16 px-6">
      <h2 className="text-2xl font-semibold mb-4">Hej! Jag heter Therese</h2>
      <p className="mb-2">Jag har arbetat med barn och unga i snart 26 år...</p>
      <p className="mb-2">Två barn med olika personligheter och behov...</p>
      <p>Jag växte upp som en blyg och högkänslig person...</p>
    </section>
  );
}
