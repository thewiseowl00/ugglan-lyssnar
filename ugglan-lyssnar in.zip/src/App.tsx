import React from "react";
import { Hero } from "./components/Hero";

export default function App() {
  return (
    <div className="font-sans bg-white text-gray-800">
      <Hero />
    </div>
  );
}
